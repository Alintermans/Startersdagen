// Ingebouwd ledje van de Arduino: pin 13, in de code LED_BUILTIN

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);  // ledje aan
  delay(1000);                      // wacht 1000 milliseconden
  digitalWrite(LED_BUILTIN, LOW);   // ledje uit
  delay(1000);
}
